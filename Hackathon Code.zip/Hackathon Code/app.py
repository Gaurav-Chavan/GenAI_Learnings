# Import Dependancies

import streamlit as st # For Frontend
from streamlit_chat import message # For message like converstation
from langchain import OpenAI # For LLM
from langchain.chains import ConversationChain # For conversation Chain
from langchain.chains.conversation.memory import ConversationBufferMemory # For Storing the conversation
import os
from utils import add_logo
from langchain.prompts import PromptTemplate # For Few shot Prompt Template
from langchain import FewShotPromptTemplate
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#    Load the environment variables
os.environ["OPENAI_API_KEY"] ="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"

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#   Define States - way to share variables between reruns, for each user session
if 'conversation' not in st.session_state:
    st.session_state['conversation'] =None
if 'messages' not in st.session_state:
    st.session_state['messages'] =[]

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# ---------------------- LLM Few Shot Prompt Template  ------------------------------------------------------------------------

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Define example template
template = """
You are a Amazon India AI Assistant based on 2023 data. 
You can share the product link and description as well. 
You can refer https://www.mysmartprice.com/gear/amazon-sale-upcoming/ for upcoming events
You can refer https://www.pricebefore.com/ for price trends
https://www.flipkart.com/ is the competitors website.

Consider the following examples:

"Friend": "Which is the costliest Mobile phone on Amazon India today?",
"AI": "The most expensive mobile phone currently available on Amazon India is the Samsung Galaxy Fold 5G 512GB. This phone is priced at Rs. 1,49,999."

"Friend": "Who is the best Seller for Samsung s22 ultra on Amazon India?",
"AI": "From sellers Appario Retail Private Ltd, TECH-RETAIL and Worldwide_Store, Appario Retail Private Ltd has more ratings 84% positive in the last 12 months (48189 ratings)"

"Friend": "What are the upcoming deals/sales on Amazon India?",
"AI": "Amazon will recently start `Super Value Days` which will be from September 1 – September 7, 2023. It will provide Up to 45% Offer on Amazon Fresh Items"

"Friend": "Whats the price trend for Samsung S22 Ultra 5G",
"AI": "Samsungs S22 Ultra's price trend varies from 85,900 INR being the lowest to 119,999 being the highest."

"Friend": "Q: Iphone 14 pro and Iphone 14 pro max, what is the difference between these 2 mobiles?",
"AI": "Size of screen. The max version enables multi device Bluetooth connectivity. The camera is also major differentiating factor especially where lenses and other hardware is concerned"

Current conversation:

{history}

Friend: {input}
AI:"""

print(template)

# Define example prompt
PROMPT  = PromptTemplate(input_variables=["history", "input"],template=template)


#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# ---------------------- LLM Module ------------------------------------------------------------------------

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Function1 : definition to get response ( LLM Model)
def getresponse(userInput):

    if st.session_state['conversation'] is None:

        llm = OpenAI(
            temperature=0.9,
            model_name='gpt-3.5-turbo-16k-0613'  #we can also use 'gpt-3.5-turbo'
        )

        st.session_state['conversation'] = ConversationChain(
            llm=llm,
            prompt=PROMPT,
            verbose=True,
            memory=ConversationBufferMemory(llm=llm,human_prefix="Friend")
        )

    response=st.session_state['conversation'].predict(input=userInput)    
    return response



#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#   UI Design


#  Setting page title and header
st.set_page_config(page_title="Amazon AI Assistance", page_icon=":tiger:")

# Create tabs
tab1, tab2 = st.tabs(["Solution","About Team"])

# Tab1 ---------- Solution Framework
with tab1:
    st.markdown("<h1 style='text-align: left;'>Hi I am Amazon AI Assistance,\n how can I help you? </h1>", unsafe_allow_html=True)
    # Here we will have a container for user input text box and response
    container = st.container()

    with container:
        # with st.form(key='my_form', clear_on_submit=True):
            user_input = st.text_area("Your question goes here:", key='input',height=100)
            submit_button = st.button(label='Send',type="primary")

            if submit_button:
                st.session_state['messages'].append(user_input)
                model_response=getresponse(user_input)
                st.session_state['messages'].append(model_response)
                for i in range(len(st.session_state['messages'])):
                    if (i % 2) == 0:
                        message(st.session_state['messages'][i], is_user=True, key=str(i) + '_user')
                    else:
                        message(st.session_state['messages'][i], key=str(i) + '_AI')

# Tab2 About Team
with tab2:
    st.image(add_logo(logo_path="logo1.jpg", width=450, height=200))
    st.divider() 
    st.title(":blue[**Team Amazonian:**]:sunglasses:")
    st.divider()
    st.markdown('''**:red[1. Gaurav Chavan  2. Padmavathi Kora  3. Muthulakshmi ]**''')
    st.divider()
    st.subheader(':orange[**About Solution:**]:rocket:')
    st.markdown('''The solution uses **gpt-3.5-turbo-16k-0613** model and utilizes ***Conversation Chain Functionality***
                amd integrating it with a ***ConversationBufferMemory***.
                For this solution, we have used ***Few-shot prompting***  to fine tune the model and help it gain contextual
                understanding.
                ''')
    st.divider()

